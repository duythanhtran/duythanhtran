﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RestaurantSoftware.P_Layer
{
    public partial class Frm_QuanLyNhapHang : Form
    {
        public Frm_QuanLyNhapHang()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Frm_ThemNhaCungCap frm = new Frm_ThemNhaCungCap();
            frm.Show();
        }
    }
}
