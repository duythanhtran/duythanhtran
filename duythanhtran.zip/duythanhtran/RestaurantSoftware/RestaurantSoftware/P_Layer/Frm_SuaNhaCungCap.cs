﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RestaurantSoftware.P_Layer
{
    public partial class Frm_SuaNhaCungCap : Form
    {
        public Frm_SuaNhaCungCap()
        {
            InitializeComponent();
        }
    }
}
